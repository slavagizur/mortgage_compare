[View Demo](http://taitems.github.com/Aristo-jQuery-UI-Theme/)
=====================

The "Aristo" theme for Cappuccino ported to a jQuery UI Theme, with permission by 280North and Pinvoke.

Distributed under an MIT license.

More information available at http://taitems.tumblr.com